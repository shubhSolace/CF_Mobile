import { LazyImgDirective } from './lazy-img.directive';

describe('LazyImgDirective', () => {
  it('should create an instance', () => {
    const directive = new LazyImgDirective();
    expect(directive).toBeTruthy();
  });
});
