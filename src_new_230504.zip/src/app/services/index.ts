export * from './get-data.service';
